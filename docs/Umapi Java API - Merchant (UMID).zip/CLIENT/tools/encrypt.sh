DIRNAME=`dirname $0`

echo "Using JAVA_HOME: $JAVA_HOME"
echo "UMAPI Directory: $DIRNAME"

DIRNAME=`cd $DIRNAME/..; pwd`

if [ "x$JAVA_HOME" != "x" ]; then
	JAVA=$JAVA_HOME/bin/java
else
	JAVA="java"
fi 


if [ -r "$DIRNAME"/lib/umapi.jar ]; then
	echo "Cannot find umapi.jar";
	exit 1;
fi

LIBS=.:$DIRNAME/config
DIRLIBS=`ls $DIRNAME/lib/*`
for i in ${DIRLIBS}; do
	if [ "$i" != "${DIRLIBS}" ] ; then
		LIBS=$LIBS:$i
	fi
done 


echo "Invoking Encryptor..."

exec "$JAVA -cp $LIBS com.wiz.enets2.transaction.util.Encryptor encrypt %1"

echo "Done"